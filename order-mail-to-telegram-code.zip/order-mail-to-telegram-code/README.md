# Code examples

Готовые примеры кода для проекта `order-mail-to-telegram`.

```text
lite/      — простые уведомления о заказах в Telegram
pro/       — уведомления + кнопка принятия + YDB + YMQ reminder
examples/  — примеры переменных окружения
docs/      — SQL для YDB
```
